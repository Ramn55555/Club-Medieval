# 2D Animated Chests Pack

The current game asset contains 10 different 2D chests 
sprites (3 frames per chest) drawn in pixel art style. 

All chests are included into 96x320 sprite sheet, but 
if you need only some of them, each chest type has 
4 png files: 
- 32x32 per chest state
- 96x32 combined sprite sheet

Author:	Lorethem
Asset's page: https://lorethem.itch.io/2d-animated-chests-pack
Projects: https://lorethem.itch.io
Contact: https://twitter.com/lorethem
License: 
This asset pack can be used in both free and commercial 
projects. You can modify it to suit your own needs. 
Credit is not needed but appreciated.  You may not 
redistribute it or resell it.